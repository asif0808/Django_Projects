from django.contrib import admin
from Base.models import Contact
admin.site.register(Contact)
